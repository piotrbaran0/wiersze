//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C_xYFJvc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/wiersze"],
		preloads: ["/assets/index-Ks8SeZlh.js", "/assets/useStore-CP8wJgJA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Ks8SeZlh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-cC-3bdKQ.js"]
	},
	"/wiersze": {
		filePath: "/workspace/src/routes/wiersze.tsx",
		children: ["/wiersze/$id", "/wiersze/"],
		preloads: ["/assets/wiersze-E741j4Pq.js"]
	},
	"/wiersze/$id": {
		filePath: "/workspace/src/routes/wiersze.$id.tsx",
		children: void 0,
		preloads: ["/assets/wiersze._id-BFSq0ppF.js", "/assets/poems-BLLn2mJl.js"]
	},
	"/wiersze/": {
		filePath: "/workspace/src/routes/wiersze.index.tsx",
		children: void 0,
		preloads: ["/assets/wiersze.index-CqnSfbKH.js", "/assets/poems-BLLn2mJl.js"]
	}
} });
//#endregion
export { tsrStartManifest };
