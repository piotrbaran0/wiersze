import { _ as Link, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as GoldRule, i as Eyebrow, r as BackLink } from "./router-CSi8vNU-.mjs";
import { a as yearSections, i as poems, n as displayName } from "./poems-DdtRezlt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wiersze.index-BwpNYFyJ.js
var import_jsx_runtime = require_jsx_runtime();
function roman(n) {
	const map = [
		[10, "X"],
		[9, "IX"],
		[5, "V"],
		[4, "IV"],
		[1, "I"]
	];
	let rest = n;
	let out = "";
	for (const [v, s] of map) while (rest >= v) {
		out += s;
		rest -= v;
	}
	return out;
}
function PoemIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "page-enter mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-6 pt-20 pb-24 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
				to: "/",
				children: "Strona główna"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mt-10 flex flex-col items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Spis treści" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 font-body text-[clamp(2rem,6vw,3.2rem)] leading-tight italic",
						children: "Wybierz wiersz"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldRule, { className: "mt-7" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-sm font-body text-base leading-relaxed text-taupe",
						children: "Każdy utwór otwiera się jak karta prywatnego tomu."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stagger-in mt-14 flex flex-col",
				children: yearSections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mb-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 font-display text-[0.62rem] tracking-[0.38em] text-champagne uppercase",
						children: section.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: section.ids.map((id) => {
						const poem = poems.find((p) => p.id === id);
						if (!poem) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/wiersze/$id",
							params: { id: String(poem.id) },
							className: "poem-link group min-h-14",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-[0.7rem] tracking-[0.18em] text-champagne",
									children: roman(poem.id)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-body text-[1.15rem] leading-snug sm:text-[1.28rem]",
									children: displayName(poem)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden font-display text-[0.6rem] tracking-[0.18em] text-muted uppercase sm:inline",
									children: poem.year
								})
							]
						}) }, poem.id);
					}) })]
				}, section.label))
			})
		]
	});
}
//#endregion
export { PoemIndex as component };
