import { _ as Link, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as GoldRule, i as Eyebrow } from "./router-CSi8vNU-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DOW2Qnoe.js
var import_jsx_runtime = require_jsx_runtime();
function SplitLine({ text, delay, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `hero-title ${className ?? ""}`,
		children: Array.from(text).map((ch, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			style: { animationDelay: `${delay + i * 32}ms` },
			children: ch === " " ? "\xA0" : ch
		}, `${ch}-${i}`))
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "relative flex min-h-dvh flex-col items-center justify-center px-6 py-24 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger-in flex max-w-3xl flex-col items-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Antologia · 2023 — 2026" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-10 flex flex-col items-center gap-3 text-ivory",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Wiersze autorstwa Piotra Barana"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitLine, {
							text: "Wiersze autorstwa",
							delay: 220,
							className: "font-body text-[clamp(2.1rem,8vw,4.6rem)] leading-[1.05] font-medium italic"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitLine, {
							text: "Piotra Barana",
							delay: 720,
							className: "font-display text-[clamp(1.7rem,6.2vw,3.4rem)] leading-[1.1] font-medium tracking-[0.08em]"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldRule, { className: "mt-10" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 max-w-md font-body text-lg leading-relaxed text-taupe italic",
					children: "Trzynaście wierszy. Prywatny tom, złożony w ciszy, między rokiem dwutysięcznym dwudziestym trzecim a dwudziestym szóstym."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/wiersze",
					className: "cta-exclusive mt-12 inline-flex min-h-12 items-center justify-center px-8 text-[0.68rem] sm:px-10",
					children: "Przejdź do wierszy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-16 font-display text-[0.62rem] tracking-[0.34em] text-muted uppercase",
					children: "XIII wierszy"
				})
			]
		})
	});
}
//#endregion
export { Home as component };
