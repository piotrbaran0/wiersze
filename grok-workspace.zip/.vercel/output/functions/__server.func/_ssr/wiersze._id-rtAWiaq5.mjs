import { i as __toESM } from "../_runtime.mjs";
import { _ as Link, b as require_jsx_runtime, v as useNavigate, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route, o as PoemScroller, r as BackLink } from "./router-CSi8vNU-.mjs";
import { n as displayName, r as getPoem, t as adjacentIds } from "./poems-DdtRezlt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wiersze._id-rtAWiaq5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PoemPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const numericId = Number(id);
	const poem = getPoem(numericId);
	(0, import_react.useEffect)(() => {
		if (!poem) navigate({ to: "/wiersze" });
	}, [poem, navigate]);
	const { prev, next } = adjacentIds(numericId);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "Escape") navigate({ to: "/wiersze" });
			if (e.key === "ArrowLeft" && prev) navigate({
				to: "/wiersze/$id",
				params: { id: String(prev) }
			});
			if (e.key === "ArrowRight" && next) navigate({
				to: "/wiersze/$id",
				params: { id: String(next) }
			});
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		navigate,
		prev,
		next
	]);
	if (!poem) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "page-enter flex h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-10 shrink-0 px-5 pt-16 pb-4 sm:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
						to: "/wiersze",
						children: "Wszystkie wiersze"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-6 flex max-w-2xl flex-col gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-body text-[clamp(1.7rem,5vw,2.6rem)] leading-tight italic",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-ivory",
								children: [
									"(",
									poem.title,
									")"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-champagne",
								children: " — Piotr Baran"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mx-auto mt-3 max-w-2xl font-display text-[0.62rem] tracking-[0.28em] text-muted uppercase",
						children: [
							poem.id,
							" Wiersz",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-2 text-champagne",
								children: "·"
							}),
							poem.year,
							poem.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-2 text-champagne",
								children: "·"
							}), poem.note] }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-5 h-px max-w-2xl bg-gradient-to-r from-transparent via-champagne/40 to-transparent" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoemScroller, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "font-body text-[clamp(1.12rem,3.4vw,1.4rem)] leading-[1.85] text-ivory-soft whitespace-pre-wrap",
				children: poem.body
			}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "relative z-10 flex shrink-0 items-center justify-between gap-4 border-t border-line px-5 py-3 sm:px-10",
				children: [
					prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/wiersze/$id",
						params: { id: String(prev) },
						className: "inline-flex min-h-11 items-center font-display text-[0.62rem] tracking-[0.22em] text-taupe uppercase transition-colors hover:text-champagne-bright",
						children: "← Poprzedni"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden font-display text-[0.58rem] tracking-[0.2em] text-muted uppercase sm:inline",
						children: displayName(poem)
					}),
					next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/wiersze/$id",
						params: { id: String(next) },
						className: "inline-flex min-h-11 items-center font-display text-[0.62rem] tracking-[0.22em] text-taupe uppercase transition-colors hover:text-champagne-bright",
						children: "Następny →"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
				]
			})
		]
	});
}
//#endregion
export { PoemPage as component };
