import { b as require_jsx_runtime, p as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wiersze-CW8CL9Em.js
var import_jsx_runtime = require_jsx_runtime();
function WierszeLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
//#endregion
export { WierszeLayout as component };
