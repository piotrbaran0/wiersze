import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/cn";

export function Atmosphere() {
  return (
    <>
      <div className="fixed inset-0 z-0 bg-ink" />
      <div
        className="fixed inset-0 z-[1] opacity-[0.22]"
        style={{
          backgroundImage: "url(/textures/paper.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <DustField />
      <CursorGlow />
      <div className="salon-vignette" />
      <div className="salon-grain" />
      <span className="corner-frame tl" />
      <span className="corner-frame tr" />
      <span className="corner-frame bl" />
      <span className="corner-frame br" />
    </>
  );
}

function DustField() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const particles = Array.from({ length: 42 }, () => ({
      x: Math.random(),
      y: Math.random(),
      r: 0.4 + Math.random() * 1.3,
      s: 0.04 + Math.random() * 0.12,
      o: 0.08 + Math.random() * 0.28,
      drift: (Math.random() - 0.5) * 0.08,
    }));

    let raf = 0;
    let running = true;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const tick = () => {
      if (!running) return;
      const w = window.innerWidth;
      const h = window.innerHeight;
      ctx.clearRect(0, 0, w, h);
      for (const p of particles) {
        p.y -= p.s / 220;
        p.x += p.drift / 280;
        if (p.y < -0.02) {
          p.y = 1.02;
          p.x = Math.random();
        }
        if (p.x < -0.02) p.x = 1.02;
        if (p.x > 1.02) p.x = -0.02;
        ctx.beginPath();
        ctx.fillStyle = `rgba(232, 220, 196, ${p.o})`;
        ctx.arc(p.x * w, p.y * h, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    };

    resize();
    window.addEventListener("resize", resize);
    raf = requestAnimationFrame(tick);
    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-[2]"
      aria-hidden="true"
    />
  );
}

function CursorGlow() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduce) return;

    const onMove = (e: PointerEvent) => {
      el.style.opacity = "1";
      el.style.transform = `translate3d(${e.clientX - 180}px, ${e.clientY - 180}px, 0)`;
    };
    const onLeave = () => {
      el.style.opacity = "0";
    };

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerleave", onLeave);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed top-0 left-0 z-[3] size-[360px] rounded-full opacity-0"
      style={{
        background: "radial-gradient(circle, rgb(201 184 150 / 0.12) 0%, transparent 68%)",
        transition: "opacity 400ms ease",
        willChange: "transform",
      }}
    />
  );
}

export function GoldRule({ className }: { className?: string }) {
  return (
    <div className={cn("gold-rule", className)} aria-hidden="true">
      <span className="diamond" />
    </div>
  );
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return (
    <p className="font-display text-[0.68rem] font-medium tracking-[0.42em] text-champagne uppercase">
      {children}
    </p>
  );
}

export function PoemScroller({ children }: { children: ReactNode }) {
  const scrollerRef = useRef<HTMLDivElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  const [needed, setNeeded] = useState(false);
  const dragging = useRef(false);

  const update = () => {
    const el = scrollerRef.current;
    if (!el) return;
    const max = el.scrollHeight - el.clientHeight;
    setNeeded(max > 12);
    setProgress(max <= 0 ? 0 : el.scrollTop / max);
  };

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    update();
    el.addEventListener("scroll", update, { passive: true });
    const ro = new ResizeObserver(update);
    ro.observe(el);
    window.addEventListener("resize", update);
    return () => {
      el.removeEventListener("scroll", update);
      ro.disconnect();
      window.removeEventListener("resize", update);
    };
  }, []);

  const setFromClientY = (clientY: number) => {
    const el = scrollerRef.current;
    const rail = railRef.current;
    if (!el || !rail) return;
    const rect = rail.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (clientY - rect.top) / rect.height));
    const max = el.scrollHeight - el.clientHeight;
    el.scrollTop = ratio * max;
  };

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    dragging.current = true;
    e.currentTarget.setPointerCapture(e.pointerId);
    setFromClientY(e.clientY);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragging.current) return;
    setFromClientY(e.clientY);
  };

  const onPointerUp = () => {
    dragging.current = false;
  };

  return (
    <div className="relative min-h-0 flex-1">
      <div
        ref={scrollerRef}
        className="poem-scroll h-full overflow-y-auto overscroll-contain"
      >
        <div className="mx-auto max-w-2xl px-5 pt-4 pr-12 pb-28 sm:px-8 sm:pr-14">
          {children}
        </div>
      </div>
      {needed ? (
        <div className="pointer-events-none absolute inset-0 mx-auto max-w-2xl">
          <div
            ref={railRef}
            className="rail pointer-events-auto"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            role="scrollbar"
            aria-orientation="vertical"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(progress * 100)}
            aria-label="Przewiń wiersz"
          >
            <div className="rail-track" />
            <div className="rail-thumb" style={{ top: `${progress * 100}%` }} />
          </div>
        </div>
      ) : null}
    </div>
  );
}

export function BackLink({
  to,
  children,
}: {
  to: string;
  children: ReactNode;
}) {
  return (
    <Link
      to={to}
      className="inline-flex min-h-11 items-center gap-2 font-display text-[0.65rem] tracking-[0.28em] text-taupe uppercase transition-colors duration-200 hover:text-champagne-bright"
    >
      <span aria-hidden="true">←</span>
      {children}
    </Link>
  );
}
