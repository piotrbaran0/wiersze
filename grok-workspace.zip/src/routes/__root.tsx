import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { Atmosphere } from "@/components/salon";
import appCss from "../styles.css?url";

const APP_NAME = "Wiersze autorstwa Piotra Barana";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      {
        name: "description",
        content: "Antologia trzynastu wierszy Piotra Barana. 2023–2026.",
      },
      { name: "theme-color", content: "#0a0908" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: RootDocument,
  notFoundComponent: NotFound,
});

function RootDocument() {
  return (
    <html lang="pl" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="bg-ink text-ivory">
        <PreviewHostBridge />
        <AuthProvider>
          <Atmosphere />
          <div className="relative z-20">
            <Outlet />
          </div>
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center px-6 text-center">
      <p className="font-display text-[0.68rem] tracking-[0.4em] text-champagne uppercase">
        Strona nie istnieje
      </p>
      <h1 className="mt-4 font-body text-4xl italic">Ta karta została wyjęta z tomu.</h1>
      <a
        href="/"
        className="cta-exclusive mt-10 inline-flex min-h-12 items-center px-8 text-[0.68rem]"
      >
        Powrót
      </a>
    </main>
  );
}
