import { createFileRoute, Link } from "@tanstack/react-router";
import { BackLink, Eyebrow, GoldRule } from "@/components/salon";
import { displayName, poems, yearSections } from "@/lib/poems";

export const Route = createFileRoute("/wiersze/")({ component: PoemIndex });

function roman(n: number): string {
  const map: [number, string][] = [
    [10, "X"],
    [9, "IX"],
    [5, "V"],
    [4, "IV"],
    [1, "I"],
  ];
  let rest = n;
  let out = "";
  for (const [v, s] of map) {
    while (rest >= v) {
      out += s;
      rest -= v;
    }
  }
  return out;
}

function PoemIndex() {
  return (
    <main className="page-enter mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-6 pt-20 pb-24 sm:px-8">
      <BackLink to="/">Strona główna</BackLink>

      <header className="mt-10 flex flex-col items-center text-center">
        <Eyebrow>Spis treści</Eyebrow>
        <h1 className="mt-5 font-body text-[clamp(2rem,6vw,3.2rem)] leading-tight italic">
          Wybierz wiersz
        </h1>
        <GoldRule className="mt-7" />
        <p className="mt-6 max-w-sm font-body text-base leading-relaxed text-taupe">
          Każdy utwór otwiera się jak karta prywatnego tomu.
        </p>
      </header>

      <div className="stagger-in mt-14 flex flex-col">
        {yearSections.map((section) => (
          <section key={section.label} className="mb-10">
            <h2 className="mb-2 font-display text-[0.62rem] tracking-[0.38em] text-champagne uppercase">
              {section.label}
            </h2>
            <ul>
              {section.ids.map((id) => {
                const poem = poems.find((p) => p.id === id);
                if (!poem) return null;
                return (
                  <li key={poem.id}>
                    <Link
                      to="/wiersze/$id"
                      params={{ id: String(poem.id) }}
                      className="poem-link group min-h-14"
                    >
                      <span className="font-display text-[0.7rem] tracking-[0.18em] text-champagne">
                        {roman(poem.id)}
                      </span>
                      <span className="font-body text-[1.15rem] leading-snug sm:text-[1.28rem]">
                        {displayName(poem)}
                      </span>
                      <span className="hidden font-display text-[0.6rem] tracking-[0.18em] text-muted uppercase sm:inline">
                        {poem.year}
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </section>
        ))}
      </div>
    </main>
  );
}
