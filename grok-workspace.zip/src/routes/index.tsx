import { createFileRoute, Link } from "@tanstack/react-router";
import { Eyebrow, GoldRule } from "@/components/salon";

export const Route = createFileRoute("/")({ component: Home });

function SplitLine({
  text,
  delay,
  className,
}: {
  text: string;
  delay: number;
  className?: string;
}) {
  return (
    <span className={`hero-title ${className ?? ""}`}>
      {Array.from(text).map((ch, i) => (
        <span key={`${ch}-${i}`} style={{ animationDelay: `${delay + i * 32}ms` }}>
          {ch === " " ? "\u00A0" : ch}
        </span>
      ))}
    </span>
  );
}

function Home() {
  return (
    <main className="relative flex min-h-dvh flex-col items-center justify-center px-6 py-24 text-center">
      <div className="stagger-in flex max-w-3xl flex-col items-center">
        <Eyebrow>Antologia · 2023 — 2026</Eyebrow>

        <h1 className="mt-10 flex flex-col items-center gap-3 text-ivory">
          <span className="sr-only">Wiersze autorstwa Piotra Barana</span>
          <SplitLine
            text="Wiersze autorstwa"
            delay={220}
            className="font-body text-[clamp(2.1rem,8vw,4.6rem)] leading-[1.05] font-medium italic"
          />
          <SplitLine
            text="Piotra Barana"
            delay={720}
            className="font-display text-[clamp(1.7rem,6.2vw,3.4rem)] leading-[1.1] font-medium tracking-[0.08em]"
          />
        </h1>

        <GoldRule className="mt-10" />

        <p className="mt-8 max-w-md font-body text-lg leading-relaxed text-taupe italic">
          Trzynaście wierszy. Prywatny tom, złożony w ciszy, między rokiem dwutysięcznym dwudziestym trzecim
          a dwudziestym szóstym.
        </p>

        <Link
          to="/wiersze"
          className="cta-exclusive mt-12 inline-flex min-h-12 items-center justify-center px-8 text-[0.68rem] sm:px-10"
        >
          Przejdź do wierszy
        </Link>

        <p className="mt-16 font-display text-[0.62rem] tracking-[0.34em] text-muted uppercase">
          XIII wierszy
        </p>
      </div>
    </main>
  );
}
