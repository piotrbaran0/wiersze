import { useEffect } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { BackLink, PoemScroller } from "@/components/salon";
import { adjacentIds, displayName, getPoem } from "@/lib/poems";

export const Route = createFileRoute("/wiersze/$id")({
  component: PoemPage,
});

function PoemPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const numericId = Number(id);
  const poem = getPoem(numericId);

  useEffect(() => {
    if (!poem) {
      void navigate({ to: "/wiersze" });
    }
  }, [poem, navigate]);

  const { prev, next } = adjacentIds(numericId);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        void navigate({ to: "/wiersze" });
      }
      if (e.key === "ArrowLeft" && prev) {
        void navigate({ to: "/wiersze/$id", params: { id: String(prev) } });
      }
      if (e.key === "ArrowRight" && next) {
        void navigate({ to: "/wiersze/$id", params: { id: String(next) } });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate, prev, next]);

  if (!poem) return null;

  return (
    <main className="page-enter flex h-dvh flex-col">
      <header className="relative z-10 shrink-0 px-5 pt-16 pb-4 sm:px-10">
        <BackLink to="/wiersze">Wszystkie wiersze</BackLink>
        <div className="mx-auto mt-6 flex max-w-2xl flex-col gap-2">
          <h1 className="font-body text-[clamp(1.7rem,5vw,2.6rem)] leading-tight italic">
            <span className="text-ivory">({poem.title})</span>
            <span className="text-champagne"> — Piotr Baran</span>
          </h1>
        </div>
        <p className="mx-auto mt-3 max-w-2xl font-display text-[0.62rem] tracking-[0.28em] text-muted uppercase">
          {poem.id} Wiersz
          <span className="mx-2 text-champagne">·</span>
          {poem.year}
          {poem.note ? (
            <>
              <span className="mx-2 text-champagne">·</span>
              {poem.note}
            </>
          ) : null}
        </p>
        <div className="mx-auto mt-5 h-px max-w-2xl bg-gradient-to-r from-transparent via-champagne/40 to-transparent" />
      </header>

      <PoemScroller>
        <article>
          <pre className="font-body text-[clamp(1.12rem,3.4vw,1.4rem)] leading-[1.85] text-ivory-soft whitespace-pre-wrap">
            {poem.body}
          </pre>
        </article>
      </PoemScroller>

      <nav className="relative z-10 flex shrink-0 items-center justify-between gap-4 border-t border-line px-5 py-3 sm:px-10">
        {prev ? (
          <Link
            to="/wiersze/$id"
            params={{ id: String(prev) }}
            className="inline-flex min-h-11 items-center font-display text-[0.62rem] tracking-[0.22em] text-taupe uppercase transition-colors hover:text-champagne-bright"
          >
            ← Poprzedni
          </Link>
        ) : (
          <span />
        )}
        <span className="hidden font-display text-[0.58rem] tracking-[0.2em] text-muted uppercase sm:inline">
          {displayName(poem)}
        </span>
        {next ? (
          <Link
            to="/wiersze/$id"
            params={{ id: String(next) }}
            className="inline-flex min-h-11 items-center font-display text-[0.62rem] tracking-[0.22em] text-taupe uppercase transition-colors hover:text-champagne-bright"
          >
            Następny →
          </Link>
        ) : (
          <span />
        )}
      </nav>
    </main>
  );
}
