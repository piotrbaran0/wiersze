import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/wiersze")({
  component: WierszeLayout,
});

function WierszeLayout() {
  return <Outlet />;
}
